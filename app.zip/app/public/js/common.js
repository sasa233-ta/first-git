$(function () {
  $('#mst_prd').click(function () {
    console.log("aaaaaaaaa");
    $('#prd-toggle').toggleClass("prd-open")
  })
})